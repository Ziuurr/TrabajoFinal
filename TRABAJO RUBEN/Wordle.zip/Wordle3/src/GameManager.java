
public class GameManager{


    public class GameManagerFacil {
        private static int contador=0;


        public static int getContador() {
            return contador;
        }

        public static void setContador(int contador) {
            GameManagerFacil.contador = contador;
        }


    }

    public class GameManagerDificil {
        private static int contador=0;


        public static int getContador() {
            return contador;
        }

        public static void setContador(int contador) {
            GameManagerDificil.contador = contador;
        }


    }
}