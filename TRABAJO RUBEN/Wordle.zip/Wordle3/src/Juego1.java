import java.util.ArrayList;
import java.util.Scanner;


public class Juego1 {
    private Scanner teclado;
    private PalabraAleatoria palabraAleatoria;
    private VerificarPalabras Verificar;

    private String [] palabras;



    private int contador=0;


    public Juego1() {
        teclado = new Scanner(System.in);
        palabras = new String[] {"abeja", "abofe", "agudo", "agua", "alba", "alado", "altar", "amigo",
                "anual", "árbol", "aroma", "arroz", "atún", "audio", "aviso", "luz", "flor", "mesa", "limón",
                "llave", "torre", "papel", "gato", "cama", "taza", "plato", "hoja", "piedra",
                "campo", "miedo", "punto", "nariz", "radio", "niño", "flaco", "grano", "risa", "onda",
                "vaca", "línea", "campo", "guapo", "radio", "copas", "lleno", "lunes", "corte", "dulce",
                "leche", "humor", "salsa", "tabla", "tinta", "marzo", "golpe", "huerto", "huella", "bello",
                "chico", "poder", "fuego", "jugar", "flota", "primo", "plaza", "caoba", "flecha", "broma",
                "fuera", "silla", "vuelo", "novio", "manga", "fiel", "campo", "abrir", "sello", "ducha",
                "vista", "pleno", "campo", "ficha", "cuerda", "tinta", "furia", "mosca", "sabor", "pleno",
                "arena", "bocas", "calma", "dados", "recuerdos", "fuego", "grito", "hojas", "irris", "jefes",
                "koala", "luzca", "marco", "nubes", "ojiva", "patas", "quema", "ruido", "salsa", "tarde",
                "uvasa", "virus", "yates", "beber", "dadle",
                "fuego", "guisa", "hijos", "ibero", "jotas", "koala", "luces", "mujer", "nardo", "ocaso",
                "pista", "quien", "raias", "saber", "talar", "vasos", "yerna",
                "zorro", "zorro", "besos", "calle", "darse", "furia", "herir", "ideas",
                "juego", "karma", "liras", "mayor", "nadar", "ocios", "parar", "queja", "rabos", "sacia"};
        palabraAleatoria = new PalabraAleatoria(palabras);
        Verificar = new VerificarPalabras();
    }

    public void Jugar() {

        System.out.println("HAS ELEGIDO PALABAS");
        System.out.println("INTENTA ADIVINAR LA PALABRA");
        String palabraAleatoria = PalabraAleatoria.ObtenerStringAtleatoria(palabras);
        palabraAleatoria=PalabraAleatoria.ArreglarTexto(palabraAleatoria);
        //System.out.println(palabraAleatoria);
        String palabra = "";


        for (int intentos = 6; intentos > 0; intentos--) {
            System.out.println("Te quedan " + intentos +" intentos");
            System.out.print("Escribe una palabra:");
            palabra = teclado.next();
            palabra=PalabraAleatoria.ArreglarTexto(palabra);

            if (Verificar.Palabras(palabra, palabraAleatoria)) {
                GameManager.GameManagerFacil.setContador(GameManager.GameManagerFacil.getContador()+1);
                System.out.println("genial ganaste !");
                System.out.println("pulsa un numero para continuar");
                break;
            }
        }

        if (!palabra.equals(palabraAleatoria)) {
            System.out.println("fallaste la palabra era " + palabraAleatoria + ".");
            System.out.println("pulsa un numero para continuar");
        }
    }

}