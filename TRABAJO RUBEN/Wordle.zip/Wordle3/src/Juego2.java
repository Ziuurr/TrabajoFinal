import java.util.Scanner;

public class Juego2 {
    private Scanner teclado;
    private PalabraAleatoria FraseAleatoria;
    private VerificarPalabras Verificar;

    private String [] frases;


    public Juego2() {
        teclado = new Scanner(System.in);
        frases= new String[]{
                "La abeja se poso en la flor", "Mi amigo se ha enfadado conmigo", "Voy a aprobar java",
                "El sol brilla intensamente", "La luna ilumina la noche", "Las estrellas titilan en el cielo",
                "El viento sopla suavemente", "Las olas rompen en la orilla", "Los pájaros cantan al amanecer",
                "La lluvia cae sobre el campo", "Las flores florecen en primavera", "Los arboles se mecen con la brisa",
                "Las hojas caen en otoño", "La nieve cubre las montañas", "El río fluye hacia el mar",
                "El fuego crepita en la chimenea", "El tiempo pasa rapidamente", "El amor es eterno",
                "La vida es un regalo", "La paz reina en el corazón", "La música alegra el alma",
                "El conocimiento es poder", "La esperanza nunca muere"
        };
        FraseAleatoria = new PalabraAleatoria(frases);
        Verificar = new VerificarPalabras();
    }

    public void Jugar() {
        System.out.println("HAS ELEGIDO FRASES");
        System.out.println("INTENTA ADIVINAR LA FRASE");
        String fraseAleatoria =PalabraAleatoria.ObtenerFraseleatoria(frases);
        fraseAleatoria=PalabraAleatoria.ArreglarTexto(fraseAleatoria);

       // System.out.println(fraseAleatoria);

        boolean acertado = false;
        for (int intentos = 6; intentos > 0; intentos--) {
            System.out.print("Escribe una frase: ");
            String frase = teclado.nextLine();
            frase=PalabraAleatoria.ArreglarTexto(frase);

            if (Verificar.Palabras(frase, fraseAleatoria)) {
                System.out.println("¡Genial, ganaste!");
                GameManager.GameManagerDificil.setContador(GameManager.GameManagerDificil.getContador()+1);
                System.out.println("pulsa un numero para continuar");
                acertado = true;
                break;
            } else {
                System.out.println("Vuelvelo a intentar te quedan "+ intentos +" de intentos");
            }
        }

        if (!acertado) {
            System.out.println("El juego ha terminado. Mejor suerte la próxima vez."+"la frase es: " + fraseAleatoria);
            System.out.println("pulsa un numero para continuar");
        }
    }
}

