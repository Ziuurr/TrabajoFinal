public class VerificarPalabras {
    public boolean Palabras(String palabra, String palabraAleatoria) {
        final String VERDE = "\u001b[42m";
        final String AMARILLO = "\u001b[43m";
        final String GRIS = "\u001b[0m";

        for (int i = 0; i < palabra.length(); i++) {
            if (i < palabraAleatoria.length() && palabraAleatoria.substring(i, i + 1).equals(palabra.substring(i, i + 1))) {
                // Letter matches
                System.out.print(VERDE + palabra.substring(i, i + 1) + GRIS);
            } else if (palabraAleatoria.contains(palabra.substring(i, i + 1))) {
                // Letter is in word, but different location
                System.out.print(AMARILLO + palabra.substring(i, i + 1) + GRIS);
            } else {
                // Letter not in word
                System.out.print(palabra.substring(i, i + 1));
            }
        }

        System.out.println("");
        return palabra.equals(palabraAleatoria);
    }
}