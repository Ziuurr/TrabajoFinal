import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        boolean bandera=false;


        do {

            try {
                Scanner teclado=new Scanner(System.in);
                do {
                    bandera = true;
                    System.out.println("Bienvenido a mi juego ");
                    System.out.println("\u001B[35m"+" |¯¯¯¯¯¯¯¯¯¯¯¯|");
                    System.out.println(" |   WORDLE   |");
                    System.out.println(" |____________|"+"\u001B[0m");
                    System.out.println("Wordle de palabras (FACIL)pulsa 1");
                    System.out.println("Wordle de frases (DIFICIL) pulsa 2");
                    System.out.println("Ver numero de victorias pulsa 3");

                    switch (teclado.nextInt()) {
                        case 1:
                            Juego1 Juegoletreas = new Juego1();
                            Juegoletreas.Jugar();
                            break;

                        case 2:
                            Juego2 JuegoFrases = new Juego2();
                            JuegoFrases.Jugar();
                            break;
                        case 3:
                            System.out.println("tienes "+ GameManager.GameManagerFacil.getContador()+" victorias en modo Facil");
                            System.out.println("tienes "+ GameManager.GameManagerDificil.getContador()+" victorias en modo Dificil");
                            System.out.println("Pulsa un numero para salir");
                            break;

                    }
                } while (teclado.nextInt()!= 4);
            }catch (Exception e){
                System.out.println("No esta permitido usar letras elija en numeros");
            }

        }while (bandera=true);

    }
}