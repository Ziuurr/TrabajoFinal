import java.text.Normalizer;
import java.util.Random;
import java.util.regex.Pattern;

public class PalabraAleatoria {
    private String[] palabras;

    public PalabraAleatoria(String[] palabras) {
        this.palabras = palabras;
    }


    public static String ObtenerStringAtleatoria(String[] palabras)
    {
        Random rand = new Random();
        int indiceAleatorio = rand.nextInt(palabras.length);
        return palabras[indiceAleatorio];

    }
    public static String ObtenerFraseleatoria(String[] frases)
    {
        Random rand = new Random();
        int indiceAleatorio = rand.nextInt(frases.length);
        return frases[indiceAleatorio];

    }

    public static String ArreglarTexto(String palabra)
    {

        palabra = palabra.toLowerCase();
        palabra = palabra.replace("á","a");
        palabra = palabra.replace("é","e");
        palabra = palabra.replace("í","i");
        palabra = palabra.replace("ó","o");
        palabra = palabra.replace("ú","u");
        palabra = palabra.replace(" ", "");
        return palabra;
    }






}